﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProje.Models;
using WebProje.Models.Services;

namespace WebProje.Controllers
{
    [Authorize] // sadece giriş yapanlar
    public class RandevuController : Controller
    {
        private readonly AppDbContext _context;
        private readonly AppointmentService _appointmentService;
        private readonly UserManager<ApplicationUser> _userManager;

        public RandevuController(
            AppDbContext context,
            AppointmentService appointmentService,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _appointmentService = appointmentService;
            _userManager = userManager;
        }

        public async Task<IActionResult> Olustur()
        {
            ViewBag.Antrenorler = await _context.Antrenorler.ToListAsync();
            ViewBag.Hizmetler = await _context.HizmetTurleri.ToListAsync();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Olustur(int antrenorId, int hizmetId, DateTime baslangic)
        {
            var user = await _userManager.GetUserAsync(User);
            int kullaniciId = user.Id;

            var hizmet = await _context.HizmetTurleri.FindAsync(hizmetId);
            if (hizmet == null) return View();

            DateTime bitis = baslangic.AddMinutes(hizmet.SureDakika);

            string kontrol = _appointmentService.RandevuUygunMu(
                kullaniciId, antrenorId, baslangic, bitis
            );

            if (kontrol != "OK")
            {
                ViewBag.Hata = kontrol;
                ViewBag.Antrenorler = await _context.Antrenorler.ToListAsync();
                ViewBag.Hizmetler = await _context.HizmetTurleri.ToListAsync();
                return View();
            }

            var randevu = new Randevu
            {
                KullaniciId = kullaniciId,
                AntrenorID = antrenorId,
                HizmetTuruID = hizmetId,
                BaslangicZamani = baslangic,
                BitisZamani = bitis,
                Durum = "Onaylandı"
            };

            _context.Randevular.Add(randevu);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);

            // Admin ise tüm randevuları görsün
            bool adminMi = await _userManager.IsInRoleAsync(user, "Admin");

            var query = _context.Randevular
                .Include(a => a.Antrenor)
                .Include(h => h.HizmetTuru)
                .AsQueryable();

            if (!adminMi)
            {
                // Üye ise sadece kendi randevuları
                int kullaniciId = user.Id;
                query = query.Where(r => r.KullaniciId == kullaniciId);
            }

            var liste = await query.ToListAsync();
            return View(liste);
        }
    }
}

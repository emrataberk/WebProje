﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using WebProje.Models;

namespace WebProje.Controllers
{
    public class KullaniciController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public KullaniciController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        public IActionResult Kayit() => View();

        [HttpPost]
        public async Task<IActionResult> Kayit(string email, string sifre)
        {
            var user = new ApplicationUser
            {
                Email = email,
                UserName = email
            };

            var result = await _userManager.CreateAsync(user, sifre);

            if (result.Succeeded)
                return RedirectToAction("Giris");

            ViewBag.Hata = string.Join("<br>", result.Errors.Select(e => e.Description));
            return View();
        }

        public IActionResult Giris() => View();

        [HttpPost]
        public async Task<IActionResult> Giris(string email, string sifre)
        {
            var result = await _signInManager.PasswordSignInAsync(email, sifre, false, false);

            if (result.Succeeded)
                return RedirectToAction("Index", "Home");

            ViewBag.Hata = "Giriş başarısız";
            return View();
        }

        public async Task<IActionResult> Cikis()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Giris");
        }
    }
}

﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using WebProje.Models;

namespace WebProje.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public AccountController(
            UserManager<IdentityUser> userManager,
            SignInManager<IdentityUser> signInManager,
            RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
        }

        // -------------------------
        // KAYIT OL (GET)
        // -------------------------
        public IActionResult Kayit()
        {
            return View();
        }

        // -------------------------
        // KAYIT OL (POST)
        // -------------------------
        [HttpPost]
        public async Task<IActionResult> Kayit(string email, string sifre)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(sifre))
            {
                ViewBag.Hata = "Alanları boş bırakmayın!";
                return View();
            }

            var user = new IdentityUser
            {
                UserName = email,
                Email = email
            };

            var result = await _userManager.CreateAsync(user, sifre);

            if (result.Succeeded)
            {
                // Yeni kullanıcıya üye rolü ver
                await _userManager.AddToRoleAsync(user, "Uye");

                return RedirectToAction("Giris");
            }
            else
            {
                ViewBag.Hata = string.Join("<br>", result.Errors.Select(x => x.Description));
                return View();
            }
        }

        // -------------------------
        // GİRİŞ (GET)
        // -------------------------
        public IActionResult Giris()
        {
            return View();
        }

        // -------------------------
        // GİRİŞ (POST)
        // -------------------------
        [HttpPost]
        public async Task<IActionResult> Giris(string email, string sifre)
        {
            var result = await _signInManager.PasswordSignInAsync(email, sifre, false, false);

            if (result.Succeeded)
            {
                return RedirectToAction("Index", "Home");
            }

            ViewBag.Hata = "Giriş başarısız. Bilgileri kontrol edin.";
            return View();
        }

        // -------------------------
        // ÇIKIŞ
        // -------------------------
        public async Task<IActionResult> Cikis()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Giris");
        }
    }
}

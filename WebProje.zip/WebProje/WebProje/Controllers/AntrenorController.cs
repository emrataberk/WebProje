﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProje.Models;

namespace WebProje.Controllers
{
    [Authorize(Roles = "Admin")]

    public class AntrenorController : Controller
    {
        private readonly AppDbContext _context;

        public AntrenorController(AppDbContext context)
        {
            _context = context;
        }

        // --------------------------------------------------------
        // 1) Listeleme
        // --------------------------------------------------------
        public async Task<IActionResult> Index()
        {
            var liste = await _context.Antrenorler
                .Include(a => a.Hizmetler)
                .ToListAsync();

            return View(liste);
        }

        // --------------------------------------------------------
        // 2) Ekle (GET)
        // --------------------------------------------------------
        public IActionResult Ekle()
        {
            return View();
        }

        // --------------------------------------------------------
        // 3) Ekle (POST)
        // --------------------------------------------------------
        [HttpPost]
        public async Task<IActionResult> Ekle(string antrenorAd, string antrenorSoyad, string uzmanlik)
        {
            var antrenor = new Antrenor
            {
                AntrenorAd = antrenorAd,
                AntrenorSoyad = antrenorSoyad,
                Uzmanlık = uzmanlik
            };

            _context.Antrenorler.Add(antrenor);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        // --------------------------------------------------------
        // 4) Düzenle (GET)
        // --------------------------------------------------------
        public async Task<IActionResult> Duzenle(int id)
        {
            var ant = await _context.Antrenorler.FindAsync(id);

            if (ant == null)
                return NotFound();

            return View(ant);
        }

        // --------------------------------------------------------
        // 5) Düzenle (POST)
        // --------------------------------------------------------
        [HttpPost]
        public async Task<IActionResult> Duzenle(int id, string antrenorAd, string antrenorSoyad, string uzmanlik)
        {
            var ant = await _context.Antrenorler.FindAsync(id);
            if (ant == null)
                return NotFound();

            ant.AntrenorAd = antrenorAd;
            ant.AntrenorSoyad = antrenorSoyad;
            ant.Uzmanlık = uzmanlik;

            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        // --------------------------------------------------------
        // 6) Sil
        // --------------------------------------------------------
        public async Task<IActionResult> Sil(int id)
        {
            var ant = await _context.Antrenorler.FindAsync(id);
            if (ant == null)
                return NotFound();

            _context.Antrenorler.Remove(ant);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        // --------------------------------------------------------
        // 7) Antrenöre Hizmet Türü Atama (GET)
        // --------------------------------------------------------
        public async Task<IActionResult> HizmetAta(int id)
        {
            var ant = await _context.Antrenorler
                .Include(a => a.Hizmetler)
                .FirstOrDefaultAsync(a => a.AntrenorID == id);

            if (ant == null)
                return NotFound();

            ViewBag.Hizmetler = await _context.HizmetTurleri.ToListAsync();
            return View(ant);
        }

        // --------------------------------------------------------
        // 8) Antrenöre Hizmet Türü Atama (POST)
        // --------------------------------------------------------
        [HttpPost]
        public async Task<IActionResult> HizmetAta(int antrenorId, int hizmetId)
        {
            var ant = await _context.Antrenorler
                .Include(a => a.Hizmetler)
                .FirstOrDefaultAsync(a => a.AntrenorID == antrenorId);

            var hizmet = await _context.HizmetTurleri.FindAsync(hizmetId);

            if (ant == null || hizmet == null)
                return NotFound();

            // Eğer atanmamışsa ekle
            if (!ant.Hizmetler.Contains(hizmet))
                ant.Hizmetler.Add(hizmet);

            await _context.SaveChangesAsync();

            return RedirectToAction("HizmetAta", new { id = antrenorId });
        }
    }
}

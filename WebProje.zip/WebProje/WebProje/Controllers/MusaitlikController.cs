﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProje.Models;

namespace WebProje.Controllers
{
    [Authorize(Roles = "Admin")]

    public class MusaitlikController : Controller
    {
        private readonly AppDbContext _context;

        public MusaitlikController(AppDbContext context)
        {
            _context = context;
        }

        // ---------------------------------------------
        // 1) Müsaitlik Listesi
        // ---------------------------------------------
        public async Task<IActionResult> Index()
        {
            var liste = await _context.Musaitlikler
                .Include(m => m.Antrenor)
                .ToListAsync();

            return View(liste);
        }

        // ---------------------------------------------
        // 2) Müsaitlik Ekle (GET)
        // ---------------------------------------------
        public async Task<IActionResult> Ekle()
        {
            ViewBag.Antrenorler = await _context.Antrenorler.ToListAsync();
            return View();
        }

        // ---------------------------------------------
        // 3) Müsaitlik Ekle (POST)
        // ---------------------------------------------
        [HttpPost]
        public async Task<IActionResult> Ekle(int antrenorId, int haftaninGunu,
            TimeSpan baslangicSaati, TimeSpan bitisSaati)
        {
            if (baslangicSaati >= bitisSaati)
            {
                ViewBag.Hata = "Başlangıç saati bitiş saatinden büyük olamaz!";
                ViewBag.Antrenorler = await _context.Antrenorler.ToListAsync();
                return View();
            }

            var musaitlik = new Musaitlik
            {
                AntrenorId = antrenorId,
                HaftaninGunu = haftaninGunu,
                BaslangicSaati = baslangicSaati,
                BitisSaati = bitisSaati
            };

            _context.Musaitlikler.Add(musaitlik);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        // ---------------------------------------------
        // 4) Silme
        // ---------------------------------------------
        public async Task<IActionResult> Sil(int id)
        {
            var m = await _context.Musaitlikler.FindAsync(id);
            if (m == null)
                return NotFound();

            _context.Musaitlikler.Remove(m);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}

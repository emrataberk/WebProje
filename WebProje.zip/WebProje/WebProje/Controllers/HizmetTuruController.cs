﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProje.Models;

namespace WebProje.Controllers
{
    [Authorize(Roles = "Admin")]

    public class HizmetTuruController : Controller
    {

        private readonly AppDbContext _context;

        public HizmetTuruController(AppDbContext context)
        {
            _context = context;
        }

        // ---------------------------
        // 1) Listeleme
        // ---------------------------
        public async Task<IActionResult> Index()
        {
            var liste = await _context.HizmetTurleri.ToListAsync();
            return View(liste);
        }

        // ---------------------------
        // 2) Ekle (GET)
        // ---------------------------
        public IActionResult Ekle()
        {
            return View();
        }

        // ---------------------------
        // 3) Ekle (POST)
        // ---------------------------
        [HttpPost]
        public async Task<IActionResult> Ekle(string ad, int sureDakika, decimal fiyat)
        {
            var hizmet = new HizmetTuru
            {
                HizmetAdi = ad,
                SureDakika = sureDakika,
                Ucret = fiyat
            };

            _context.HizmetTurleri.Add(hizmet);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        // ---------------------------
        // 4) Düzenle (GET)
        // ---------------------------
        public async Task<IActionResult> Duzenle(int id)
        {
            var hizmet = await _context.HizmetTurleri.FindAsync(id);
            if (hizmet == null)
                return NotFound();

            return View(hizmet);
        }

        // ---------------------------
        // 5) Düzenle (POST)
        // ---------------------------
        [HttpPost]
        public async Task<IActionResult> Duzenle(int id, string ad, int sureDakika, decimal fiyat)
        {
            var hizmet = await _context.HizmetTurleri.FindAsync(id);
            if (hizmet == null)
                return NotFound();

            hizmet.HizmetAdi = ad;
            hizmet.SureDakika = sureDakika;
            hizmet.Ucret = fiyat;

            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        // ---------------------------
        // 6) Silme
        // ---------------------------
        public async Task<IActionResult> Sil(int id)
        {
            var hizmet = await _context.HizmetTurleri.FindAsync(id);
            if (hizmet == null)
                return NotFound();

            _context.HizmetTurleri.Remove(hizmet);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }
    }
}

﻿using WebProje.Models.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using WebProje.Models;

var builder = WebApplication.CreateBuilder(args);

// ---------------------
// Database + Identity
// ---------------------
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddIdentity<IdentityUser, IdentityRole>()
    .AddEntityFrameworkStores<AppDbContext>()
    .AddDefaultTokenProviders();

// Kullanıcı girişleri için cookie yapısı
builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Giris";
});

// Servisler
builder.Services.AddControllersWithViews();
builder.Services.AddScoped<AppointmentService>();

var app = builder.Build();

// --------------------
// Rol ve Admin oluşturma
// --------------------
using (var scope = app.Services.CreateScope())
{
    var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
    var userManager = scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>();

    string[] roller = { "Admin", "Uye" };

    foreach (var rol in roller)
    {
        if (!await roleManager.RoleExistsAsync(rol))
        {
            await roleManager.CreateAsync(new IdentityRole(rol));
        }
    }

    // Admin kullanıcısını oluştur
    string adminEmail = "ogrencinumarasi@sakarya.edu.tr";
    string adminPass = "sau";

    var adminUser = await userManager.FindByEmailAsync(adminEmail);

    if (adminUser == null)
    {
        var yeniAdmin = new IdentityUser
        {
            UserName = adminEmail,
            Email = adminEmail
        };

        var sonuc = await userManager.CreateAsync(yeniAdmin, adminPass);

        if (sonuc.Succeeded)
        {
            await userManager.AddToRoleAsync(yeniAdmin, "Admin");
        }
    }
}

// --------------------
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.UseAuthentication();   // <-- Çok önemli
app.UseAuthorization();    // <-- Çok önemli

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

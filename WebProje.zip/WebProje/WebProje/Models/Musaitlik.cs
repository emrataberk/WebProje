﻿using System.ComponentModel.DataAnnotations;

namespace WebProje.Models
{
	public class Musaitlik
	{
		[Key]
		public int Id { get; set; }
		public int AntrenorId { get; set; }
		public int HaftaninGunu { get; set; } // Daha sonra bunu bir enum ile yönetebilirsiniz.
		public TimeSpan BaslangicSaati { get; set; } // Sadece saat bilgisini tutmak daha kolaydır
		public TimeSpan BitisSaati { get; set; }

		// Navigasyon Özelliği
		public Antrenor Antrenor { get; set; }
	}
}

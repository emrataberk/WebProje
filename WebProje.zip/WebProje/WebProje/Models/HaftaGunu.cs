﻿namespace WebProje.Models
{
    public enum HaftaGunu
    {
        Pazar = 0,
        Pazartesi = 1,
        Salı = 2,
        Çarşamba = 3,
        Perşembe = 4,
        Cuma = 5,
        Cumartesi = 6
    }
}

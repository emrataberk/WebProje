﻿using System.ComponentModel.DataAnnotations;

namespace WebProje.Models
{
	public class Randevu
	{
		[Key]
		public int RandevuID { get; set; }

		[Required]
		public int KullaniciId { get; set; }  // Üye tablosu için foreign key

		[Required]
		public int AntrenorID { get; set; }

		[Required]
		public int HizmetTuruID { get; set; }

		[Required]
		public DateTime BaslangicZamani { get; set; }

		[Required]
		public DateTime BitisZamani { get; set; }

		[Required]
		[MaxLength(20)]
		public string Durum { get; set; } = "Onay Bekliyor";
		// Durumlar: Onay Bekliyor, Onaylandı, İptal Edildi

		// Navigation Properties
		public Antrenor Antrenor { get; set; }
		public HizmetTuru HizmetTuru { get; set; }

		// Kullanıcı modeli henüz gelmediği için Navigation şimdilik opsiyonel
		// public Kullanici Kullanici { get; set; }
	}
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebProje.Models
{
	public class HizmetTuru
	{
		[Key]
		public int HizmetTuruID { get; set; }

		[Required]
		[MaxLength(100)]
		public string HizmetAdi { get; set; }

		[Required]
		[Range(1, 300)]
		public int SureDakika { get; set; }   // Örn: 60 dk

		[Required]
		[Column(TypeName = "decimal(10,2)")]
		public decimal Ucret { get; set; }

		// Navigation: Bu hizmeti verebilen antrenörler
		public ICollection<Antrenor> Antrenorler { get; set; }

		// Randevular (Bu hizmet için alınmış randevular)
		public ICollection<Randevu> Randevular { get; set; }
	}
}

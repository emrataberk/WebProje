﻿using System.ComponentModel.DataAnnotations;

namespace WebProje.Models
{
	public class Antrenor
	{
		[Key]
		public int AntrenorID { get; set; }
		public string AntrenorAd {  get; set; }
		public string AntrenorSoyad {  get; set; }
		public string Uzmanlık {  get; set; }
		public ICollection<HizmetTuru> Hizmetler { get; set; }
		public ICollection<Musaitlik> MusaitlikSaatleri { get; set; }
		public ICollection<Randevu> Randevular { get; set; }
	}
}

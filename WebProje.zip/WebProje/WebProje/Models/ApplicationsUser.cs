﻿using Microsoft.AspNetCore.Identity;

namespace WebProje.Models
{
    public class ApplicationUser : IdentityUser<int>
    {
        // Ek alanların varsa buraya eklersin
    }
}

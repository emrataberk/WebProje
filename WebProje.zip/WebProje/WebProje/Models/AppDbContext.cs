﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace WebProje.Models
{
    public class AppDbContext : IdentityDbContext<ApplicationUser, IdentityRole<int>, int>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<Antrenor> Antrenorler { get; set; }
        public DbSet<Musaitlik> Musaitlikler { get; set; }
        public DbSet<HizmetTuru> HizmetTurleri { get; set; }
        public DbSet<Randevu> Randevular { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Antrenor>()
                .HasMany(a => a.Hizmetler)
                .WithMany(h => h.Antrenorler)
                .UsingEntity(j => j.ToTable("AntrenorHizmet"));

            modelBuilder.Entity<Musaitlik>()
                .HasOne(m => m.Antrenor)
                .WithMany(a => a.MusaitlikSaatleri)
                .HasForeignKey(m => m.AntrenorId);

            modelBuilder.Entity<Randevu>()
                .HasOne(r => r.Antrenor)
                .WithMany(a => a.Randevular)
                .HasForeignKey(r => r.AntrenorID);

            modelBuilder.Entity<Randevu>()
                .HasOne(r => r.HizmetTuru)
                .WithMany(h => h.Randevular)
                .HasForeignKey(r => r.HizmetTuruID);
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;

namespace WebProje.Models.Services
{
	public class AppointmentService
	{
		private readonly AppDbContext _context;

		public AppointmentService(AppDbContext context)
		{
			_context = context;
		}

		public bool AntrenorMusaitMi(int antrenorId, DateTime baslangic, DateTime bitis)
		{
			var gun = (int)baslangic.DayOfWeek;
			return _context.Musaitlikler.Any(m =>
				m.AntrenorId == antrenorId &&
				m.HaftaninGunu == gun &&
				m.BaslangicSaati <= baslangic.TimeOfDay &&
				m.BitisSaati >= bitis.TimeOfDay
			);
		}

		public bool AntrenorRandevuCakisiyorMu(int antrenorId, DateTime baslangic, DateTime bitis)
		{
			return _context.Randevular.Any(r =>
				r.AntrenorID == antrenorId &&
				(baslangic < r.BitisZamani && bitis > r.BaslangicZamani)
			);
		}

		public bool KullaniciRandevuCakisiyorMu(int kullaniciId, DateTime baslangic, DateTime bitis)
		{
			return _context.Randevular.Any(r =>
				r.KullaniciId == kullaniciId &&
				(baslangic < r.BitisZamani && bitis > r.BaslangicZamani)
			);
		}

		public string RandevuUygunMu(int kullaniciId, int antrenorId, DateTime baslangic, DateTime bitis)
		{
			if (!AntrenorMusaitMi(antrenorId, baslangic, bitis))
				return "Antrenör bu saat aralığında müsait değil.";

			if (AntrenorRandevuCakisiyorMu(antrenorId, baslangic, bitis))
				return "Antrenör bu saat için zaten bir randevuya sahip.";

			if (KullaniciRandevuCakisiyorMu(kullaniciId, baslangic, bitis))
				return "Aynı saatlerde sizin başka bir randevunuz mevcut.";

			return "OK";
		}

        internal string RandevuUygunMu(string kullaniciId, int antrenorId, DateTime baslangic, DateTime bitis)
        {
            throw new NotImplementedException();
        }
    }
}
